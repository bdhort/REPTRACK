const plans=[
 {day:"MON",name:"Upper Body",time:"12 min",icon:"↗",warm:["Shoulder rolls — 30 sec","Arm circles — 30 sec","Gentle seated arm swings — 1 min"],main:["Seated arm punches — 30 sec","Seated shoulder presses (no weights) — 8–12 reps","Seated bicep curls (no weights) — 8–12 reps","Shoulder blade squeezes — 8–12 reps","Seated arm raises — 8–10 reps"],cool:["Gentle shoulder stretch","Gentle arm stretch","Slow breathing"]},
 {day:"WED",name:"Core & Mobility",time:"10 min",icon:"◉",warm:["Gentle shoulder rolls","Easy seated torso turns, only if comfortable"],main:["Seated abdominal tightening — 5 gentle breaths","Small seated side bends — 5 each side, if comfortable","Seated overhead reaches — 6–8 reps","Shoulder blade squeezes — 8 reps"],cool:["Gentle upper-back stretch","Slow breathing"]},
 {day:"FRI",name:"Full Upper Body",time:"12 min",icon:"✦",warm:["Arm circles — small and slow","Shoulder rolls","Gentle seated punches"],main:["Seated arm punches — 20 sec","Seated bicep curls — 8–12 reps","Seated shoulder presses — 8–10 reps","Shoulder blade squeezes — 8–12 reps","Seated arm raises — 8 reps"],cool:["Gentle arm stretch","Shoulder stretch","Slow breathing"]}
];
const defaults={done:[false,false,false],xp:0,total:0,mood:"good",pain:"no",history:[]};
let state={...defaults,...JSON.parse(localStorage.getItem("wz-state")||"{}")};
function save(){localStorage.setItem("wz-state",JSON.stringify(state));render()}
function level(){return Math.floor(state.xp/100)+1}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function render(){
 document.getElementById("level").textContent=level();document.getElementById("level2").textContent=level();
 document.getElementById("xp").textContent=state.xp%100;document.getElementById("xpbar").style.width=(state.xp%100)+"%";
 document.getElementById("totalDone").textContent=state.total;document.getElementById("totalXP").textContent=state.xp;
 document.getElementById("challengeCount").textContent=state.done.filter(Boolean).length+" of 3 sessions";
 document.getElementById("challengeBar").style.width=(state.done.filter(Boolean).length/3*100)+"%";
 document.getElementById("weekCards").innerHTML=plans.map((p,i)=>`<div class="week-card"><div class="day-icon">${p.icon}</div><div class="week-info"><b>${p.day} · ${p.name}</b><small>${p.time} · No equipment</small></div><span class="status ${state.done[i]?'done':''}">${state.done[i]?'✓ Done':'Planned'}</span></div>`).join("");
 document.getElementById("workoutList").innerHTML=plans.map((p,i)=>`<article class="card workout" id="w${i}"><div class="workout-head" onclick="document.getElementById('w${i}').classList.toggle('open')"><div class="day-icon">${p.icon}</div><div><b>${p.day} · ${p.name}</b><small>${p.time} · Beginner</small></div><span>${state.done[i]?'✓':'＋'}</span></div><div class="workout-detail"><h3>Warm-up</h3>${p.warm.map(x=>`<div class="exercise">${x}</div>`).join("")}<h3>Main session</h3>${p.main.map(x=>`<div class="exercise">${x}</div>`).join("")}<h3>Cool-down</h3>${p.cool.map(x=>`<div class="exercise">${x}</div>`).join("")}<label class="complete-row"><input type="checkbox" ${state.done[i]?'checked':''} onchange="complete(${i},this.checked)"> Mark session complete</label></div></article>`).join("");
 document.getElementById("historyList").innerHTML=plans.map((p,i)=>`<div class="history-row"><span>${p.day} · ${p.name}</span><span>${state.done[i]?'Completed':'Not completed'}</span></div>`).join("");
 document.querySelectorAll(".mood").forEach(b=>b.classList.toggle("selected",b.dataset.mood===state.mood));
 document.getElementById("pain").value=state.pain;
}
function complete(i,checked){if(checked&&!state.done[i]){state.xp+=25;state.total+=1;toast("+25 XP · Nice work!")};if(!checked&&state.done[i]){state.xp=Math.max(0,state.xp-25);state.total=Math.max(0,state.total-1)}state.done[i]=checked;save()}
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
function go(id){document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===id));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===id));window.scrollTo(0,0)}
document.querySelectorAll(".mood").forEach(b=>b.addEventListener("click",()=>{state.mood=b.dataset.mood;render()}));
document.getElementById("saveCheckin").addEventListener("click",()=>{state.pain=document.getElementById("pain").value;save();const note=document.getElementById("checkinNote");if(state.pain!=="no"||state.mood==="sore"){note.textContent="Choose rest today. Because of your previously mentioned lower-leg symptoms, tell a parent/guardian and get medical guidance before exercising that leg."}else if(state.mood==="tired"||state.mood==="okay"){note.textContent="Consider a shorter, easier session—or rest. You never need to make up a missed workout."}else{note.textContent="Thanks for checking in. Keep movements gentle and stop if anything hurts."}toast("Check-in saved")});
document.getElementById("reset").addEventListener("click",()=>{if(confirm("Reset this week's workout checkmarks? Your all-time XP and history stay saved.")){state.done=[false,false,false];save();toast("Weekly checkmarks reset")}});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./service-worker.js").catch(()=>{});
render();