REPZONE — iPHONE INSTALL GUIDE

This is a Progressive Web App (PWA). It can be installed on an iPhone Home Screen and opens in its own app-style window.

IMPORTANT: iPhone installation requires the app files to be hosted on an HTTPS website. A ZIP file alone cannot install an app directly.

EASIEST PUBLISHING ROUTE
1. Upload the contents of this folder to a static HTTPS host such as GitHub Pages or Netlify.
2. Open the published HTTPS address in Safari on your iPhone.
3. Tap the Share button.
4. Choose "Add to Home Screen".
5. Keep "Open as Web App" enabled if shown, then tap Add.

FEATURES
- Dark navy / electric-blue design
- Daily mood and pain check-in
- Three short beginner sessions
- XP and levels
- Weekly challenge progress
- Workout completion history
- Offline caching after the first successful load
- Progress saved in the browser on that device

SAFETY
This starter plan intentionally avoids jumping and strenuous leg work because the user previously mentioned lower-leg pain and swelling. If symptoms are ongoing, talk with a parent/guardian and healthcare professional before exercising that leg. Stop if anything hurts. This app is not medical advice and does not diagnose or clear anyone for exercise.

CUSTOMIZATION
Edit app.js for workouts and styles.css for visual design. User progress is stored locally in the browser; it does not sync across devices.
